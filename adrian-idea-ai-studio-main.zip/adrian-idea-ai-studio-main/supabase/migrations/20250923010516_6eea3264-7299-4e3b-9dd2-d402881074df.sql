-- Add national_id column to employees table
ALTER TABLE public.employees 
ADD COLUMN national_id TEXT;